package com.ibm.library.exception;

public class BadValue extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BadValue() {
		System.out.println("BadValue Exception");
	}

	public static String ExceptionMessage(int value) {
		return "Bad Value Expcetion: "+value;
	}
	
}
