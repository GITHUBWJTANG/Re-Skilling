package com.ibm.library.service;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.library.model.Book;
import com.ibm.library.repo.LibraryRepo;


//LibraryService libraryService = new LibraryServiceImpl();
//springAppContextMap.put("LibraryService", libraryService);
@Service
public class LibraryServiceImpl implements LibraryService {
	
	// private LibraryRepo libraryRepo = springAppContextMap.get("LibraryRepo");
	// Interface libraryRepo is a variable that is now pointing to an object of LibraryRepoImpl <--- which LibraryServiceImpl shouldn't know about LibraryRepoImpl
	@Autowired
	private LibraryRepo libraryRepo; //the only place LibraryRepo object should be created, in/by LibraryServiceImpl

	@Override
	public List<Book> getBooks(String source) throws IOException {

		List<Book> books = null;
		try {
			books = this.libraryRepo.getBooks(source);
		} catch (IOException e) {
			e.printStackTrace();
		}

		double lateFee = 0.0;
		int numDaysLate = 0;
		Book book = null;

		Iterator<Book> booksIter = books.iterator();

		while (booksIter.hasNext()) {
			book = booksIter.next();

			// 1- If the book's author is "Tom Smith", it appends " - CHECKED" to the author
			if (book.getAuthor().equals("Tom Smith")) {
				book.setAuthor(book.getAuthor() + "- CHECKED");
			}
			// 2-Call each model book's calculateLateFee(numberOfDaysLate) method, passing
			// in the numberOfDaysLate parameter
			// Before calling model book's calculateLateFee(numberOfDaysLate) method, set
			// value of numberOfDaysLate parameter as follows:
			// if the # of characters in the book's title is an odd # then set
			// numberOfDaysLate to: -1 * the # of characters in the book's title
			// else set numberOfDaysLate to: # of characters in the book's title
			String exceptionMsg = null;
			if (book.getTitle().length() % 2 == 1) {
				numDaysLate = -1 * book.getTitle().length();
			} else {
				numDaysLate = book.getTitle().length();
			}

			lateFee = book.calculateLateFee(numDaysLate);
			if (lateFee == -1) {
				exceptionMsg = book.Somethingwrong(numDaysLate);
			} // temporary solution, to be improved

			// 3-Use the result of book's calculateLateFee(numberOfDaysLate) method to set
			// the book's 'notes' field as follows:
			// If book's calculateLateFee(numberOfDaysLate) throws BadValue exception,
			// LibraryServiceImpl's getBooks() method sets the book's 'notes' field to
			// BadValue's exception message

			if (exceptionMsg != null) {
				book.setNotes(exceptionMsg);
			}
			// If book's calculateLateFee(numberOfDaysLate) does NOT throw BadValue
			// exception, LibraryServiceImpl's getBooks() method sets the book's 'notes'
			// field to "Fee is: " + fee where 'fee' is the value returned from book's
			// calculateLateFee(numberOfDaysLate)
			else {
				book.setNotes("Fee is: " + lateFee);
			}
		}
		return books;
	}
}