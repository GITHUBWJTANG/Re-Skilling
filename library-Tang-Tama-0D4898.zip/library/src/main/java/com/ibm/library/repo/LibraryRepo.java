package com.ibm.library.repo;

import java.io.IOException;
import java.util.List;

import com.ibm.library.model.Book;

public interface LibraryRepo {

	List<Book> getBooks(String source) throws IOException;

}
