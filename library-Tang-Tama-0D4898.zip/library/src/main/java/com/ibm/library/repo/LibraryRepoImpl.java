package com.ibm.library.repo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Component;

import com.ibm.library.model.Book;
import com.ibm.library.model.BookFiction;
import com.ibm.library.model.BookNonFiction;

@Component
public class LibraryRepoImpl implements LibraryRepo {

	@Override
	public List<Book> getBooks(String source) throws IOException {

		List<Book> listOfBooks = new ArrayList<Book>();
		Path pathFileToRead = Paths.get(source); // "./resources/bookData.txt
		Book book = null;
		List<String> readBookList = Files.lines(pathFileToRead).collect(Collectors.toList());

		Object[] bookEntry = readBookList.toArray();
		// System.out.println("DEV_Number of books: "+readBookList.size());

		for (int i = 0; i < readBookList.size(); i++) {
			String record = (String) bookEntry[i];
			String[] element = record.split("\\|"); // current file data separator, subject to change.

			String bookType = element[0];
			String bookIsbn = element[1];
			String bookTitle = element[2];
			String bookAuthor = element[3];

			if (bookType.equals("FICTION")) {
				book = new BookFiction(bookIsbn, bookTitle, bookAuthor);
			} else if (bookType.equals("NONFICTION")) {
				book = new BookNonFiction(bookIsbn, bookTitle, bookAuthor);
			}

			if (book != null) {
				listOfBooks.add(book);
			}
			// System.out.println("DEV_This book is: "+Arrays.asList(book));

		}

		// System.out.println("DEV_List of Books: "+listOfBooks);

		return listOfBooks;

	}
}