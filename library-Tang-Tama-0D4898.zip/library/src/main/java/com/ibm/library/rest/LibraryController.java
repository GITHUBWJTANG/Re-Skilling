package com.ibm.library.rest;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ibm.library.model.Book;
import com.ibm.library.service.LibraryService;

@RestController
public class LibraryController {
	String dir = "./src/main/resources/bookData.txt";

	// private LibraryService libraryService = springAppContextMap.get("LibraryService");
	// Interface libraryService is a variable that is now pointing to an object of LibraryServiceImpl <--- RestController shouldn't know
	@Autowired
	private LibraryService libraryService;
	
	@GetMapping("/book")
	public List<Book> getAllBooks() throws IOException {

		return (List<Book>) libraryService.getBooks(dir);
	}

}
