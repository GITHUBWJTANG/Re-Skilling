package com.ibm.library.model;

public abstract class Book {
	String isbn;
	String title;
	String author;
	String notes;

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Book(String isbn, String title, String author) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.author = author;
		// this.notes = notes;
	}

	public abstract double calculateLateFee(int numDaysLate);
	public abstract String Somethingwrong(int wrongDay);
	@Override
	public String toString() {
		return "book [ISBN=" + isbn + ", Title=" + title + ", Author=" + author + "]";
	}
}
