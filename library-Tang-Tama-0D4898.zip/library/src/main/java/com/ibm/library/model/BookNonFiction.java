package com.ibm.library.model;

import com.ibm.library.exception.BadValue;

public class BookNonFiction extends Book {

	public BookNonFiction(String isbn, String title, String author) {
		super(isbn, title, author);
	}

	@Override
	public double calculateLateFee(int numDaysLate) {

		double lateFee = 0;
		try {
			if (numDaysLate < 0) {
				throw new BadValue();
			} else {
				lateFee = (numDaysLate / 1.5) * 80;
				//System.out.println("late Fee = " + lateFee);
			}
		} catch (BadValue exBV) {
			//Somethingwrong(numDaysLate);
			return -1;
		}

		return lateFee;
	}
	@Override
	public String Somethingwrong(int wrongDay) {
		return BadValue.ExceptionMessage(wrongDay);
		
	}
}
