package com.ibm.library.service;

import java.io.IOException;
import java.util.Collection;


import com.ibm.library.model.Book;


public interface LibraryService {

	Collection<Book> getBooks(String source) throws IOException;

}
